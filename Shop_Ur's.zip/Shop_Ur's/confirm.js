var list1 = [];
var sum=0;
var totaly = 0;

localStorage.setItem('listy', JSON.stringify(list1));
localStorage.setItem('total', JSON.stringify(totaly));
localStorage.setItem('sumo', JSON.stringify(sum));